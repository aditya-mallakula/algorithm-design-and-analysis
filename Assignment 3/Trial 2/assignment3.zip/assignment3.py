import sys
import os
sys.setrecursionlimit(10**6)


def main():
    if len(sys.argv) != 2:
        print("Usage: python assignment3.py Input.txt")
        return

    input_file = sys.argv[1]
    output_file = input_file.replace('Input', 'Output', 1)

    # Read input from file
    try:
        with open(input_file, 'r') as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        print(f"Error: File '{input_file}' not found.")
        return

    if len(lines) < 3:
        print("Error: Input file must contain three lines: s1, s2, and s3.")
        return

    s1, s2, s3 = lines[0], lines[1], lines[2]

    len_s1, len_s2, len_s3 = len(s1), len(s2), len(s3)

    # Early check
    if len_s1 + len_s2 != len_s3:
        write_output(output_file, False, 0, [], [])
        return

    # Memoization and results initialization
    memo = {}
    total_interleavings = 0
    substrings_s1, substrings_s2 = [], []
    substrings_found = False

    def dp(i, j, last_used, n_s1, n_s2, path_s1, path_s2):
        """
        Recursive function to check interleaving using dynamic programming.
        Parameters:
        - i, j: Current indices in s1 and s2
        - last_used: Last used string (1 for s1, 2 for s2)
        - n_s1, n_s2: Substring counts for s1 and s2
        - path_s1, path_s2: Accumulated substrings from s1 and s2
        Returns:
        - Number of valid interleavings
        """
        nonlocal total_interleavings, substrings_found

        # Memoization key
        key = (i, j, last_used, n_s1, n_s2)
        if key in memo:
            return memo[key]

        k = i + j  # Combined index in s3

        # Base case: If we've used all of s3
        if k == len_s3:
            if i == len_s1 and j == len_s2 and abs(n_s1 - n_s2) <= 1:
                total_interleavings += 1
                if not substrings_found:
                    substrings_s1.extend(path_s1)
                    substrings_s2.extend(path_s2)
                    substrings_found = True
                return 1
            return 0

        count = 0

        # Helper function to handle substrings
        def try_substring(source, idx, last_used_value, path, n_count):
            nonlocal count
            max_len = min(len(source) - idx, len_s3 - k)
            for l in range(max_len, 0, -1):
                if source[idx:idx+l] == s3[k:k+l]:
                    new_path = path + [source[idx:idx+l]]
                    res = dp(i + l * (source == s1), j + l * (source == s2),
                             last_used_value, n_s1 + (source == s1), n_s2 + (source == s2),
                             new_path if source == s1 else path_s1,
                             new_path if source == s2 else path_s2)
                    count += res

        # Try substrings from s1
        if last_used != 1 and n_s1 <= n_s2 + 1 and i < len_s1:
            try_substring(s1, i, 1, path_s1, n_s1)

        # Try substrings from s2
        if last_used != 2 and n_s2 <= n_s1 + 1 and j < len_s2:
            try_substring(s2, j, 2, path_s2, n_s2)

        memo[key] = count
        return count

    # Run the DP function
    dp(0, 0, 0, 0, 0, [], [])

    # Determine if interleaving exists
    interleaving_exists = total_interleavings > 0

    # Write output to file
    write_output(output_file, interleaving_exists, total_interleavings, substrings_s1, substrings_s2)


def write_output(output_file, interleaving_exists, total_interleavings, substrings_s1, substrings_s2):
    """
    Writes the output to the specified file.
    """
    with open(output_file, 'w') as f:
        f.write(f"Interleaving exists: {interleaving_exists}, Count of interleavings: {total_interleavings}\n")
        if interleaving_exists:
            f.write("s1 substrings: " + ', '.join(substrings_s1) + '\n')
            f.write("s2 substrings: " + ', '.join(substrings_s2) + '\n')


if __name__ == "__main__":
    main()
