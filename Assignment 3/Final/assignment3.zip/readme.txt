Assignment 3 - Implementing Interleaving two strings using dynamic programming in Python 3.

Team members: NAME - EMAIL - UID
1. Aditya Mallakula – mallakula.2@wright.edu – U01093160
2. Chris Davis Jaldi – jaldi.2@wright.edu – U01099335
3. Vanaja Uppala – uppala.19@wright.edu – U01080568

How to run the code?

- assignment3.py:
	1. Open the current working directory on terminal.
	2. Enter the command: python assignment3.py <input_filename.txt>
	3. Output.txt file will be generated.
