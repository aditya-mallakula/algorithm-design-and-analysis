Assignment 1 - Implementing Gale-Shapley Algorithm for Study Stable Marriage Problem in Python 3.

Team members: NAME - EMAIL - UID
1. Aditya Mallakula – mallakula.2@wright.edu – U01093160
2. Chris Davis Jaldi – jaldi.2@wright.edu – U01099335
3. Vanaja Uppala – uppala.19@wright.edu – U01080568


How to run the code?

- assignment1.py:
	1. Open the current working directory on terminal.
	2. Enter the command: python assignment1.py <input_filename.txt>
	3. Output.txt and OutputToBeVerified.txt files will be generated.

- stabilityChecker.py:
	1. Open the current working directory on terminal.
	2. Enter the command: python stabilityChecker.py <input_filename.txt> <OutputToBeVerified.txt>
	3. Verified.txt file will be generated.